import express from "express";
import axios from "axios";
import cors from "cors";

const app = express();
const PORT = process.env.PORT || 3001; // Vercel ke liye dynamic port

app.use(cors());

app.get("/self-api", async (req, res) => {
    try {
        const { q } = req.query;

        if (!q || typeof q !== "string") {
            return res.status(400).json({ error: "Query parameter ?q is required" });
        }

        // ✅ Clipzag se search results fetch karna
        const url = `https://clipzag.com/search?q=${encodeURIComponent(q)}`;
        const response = await axios.get(url);
        const html = response.data;

        // ✅ Regex se data extract karna
        const regex = /<a class='title-color' href='watch\?v=([^']+)'>[\s\S]*?<img .*?data-thumb='([^']+)'.*?>[\s\S]*?<div class='title-style' title='([^']+)'>(.*?)<\/div>[\s\S]*?<a class='by-user' href='\/channel\?id=([^']+)'>(.*?)<\/a>/g;
        let matches;
        let results = [];

        while ((matches = regex.exec(html)) !== null) {
            results.push({
                id: `https://youtu.be/${matches[1]}`,
                title: matches[3].trim(),
                thumbnail: `https:${matches[2]}`,
                channel_name: matches[5].trim(),
                channel_id: matches[4],
                channel_poster: `https://yt3.googleusercontent.com/ytc/${matches[4]}`
            });
        }

        res.json({ query: q, results });

    } catch (error) {
        console.error("Error:", error.message);
        res.status(500).json({ error: "Failed to fetch data", details: error.message });
    }
});

// ✅ YouTube v3 API jaisa JSON format
app.get("/v3-api", async (req, res) => {
    try {
        const { q } = req.query;

        if (!q || typeof q !== "string") {
            return res.status(400).json({ error: "Query parameter ?q is required" });
        }

        // ✅ Clipzag se search results fetch karna
        const url = `https://clipzag.com/search?q=${encodeURIComponent(q)}`;
        const response = await axios.get(url);
        const html = response.data;

        // ✅ Regex se data extract karna
        const regex = /<a class='title-color' href='watch\?v=([^']+)'>[\s\S]*?<img .*?data-thumb='([^']+)'.*?>[\s\S]*?<div class='title-style' title='([^']+)'>(.*?)<\/div>[\s\S]*?<a class='by-user' href='\/channel\?id=([^']+)'>(.*?)<\/a>/g;
        let matches;
        let results = [];

        while ((matches = regex.exec(html)) !== null) {
            results.push({
                kind: "youtube#searchResult",
                etag: null,
                id: {
                    kind: "youtube#video",
                    videoId: matches[1] || null
                },
                snippet: {
                    publishedAt: null, 
                    channelId: matches[4] || null,
                    title: matches[3]?.trim() || null,
                    description: null,
                    thumbnails: {
                        default: {
                            url: `https:${matches[2]}` || null,
                            width: 120,
                            height: 90
                        },
                        medium: {
                            url: `https:${matches[2]}` || null,
                            width: 320,
                            height: 180
                        },
                        high: {
                            url: `https:${matches[2]}` || null,
                            width: 480,
                            height: 360
                        }
                    },
                    channelTitle: matches[5]?.trim() || null,
                    liveBroadcastContent: "none",
                    publishTime: null
                }
            });
        }

        res.json({
            kind: "youtube#searchListResponse",
            etag: null,
            nextPageToken: null,
            prevPageToken: null,
            regionCode: "IN",
            pageInfo: {
                totalResults: results.length,
                resultsPerPage: results.length
            },
            items: results
        });

    } catch (error) {
        console.error("Error:", error.message);
        res.status(500).json({ error: "Failed to fetch data", details: error.message });
    }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// ✅ Vercel ke liye export
export default app;
