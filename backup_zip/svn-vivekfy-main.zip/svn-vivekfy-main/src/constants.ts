export const globalConstants = {
  status: {
    success: 'SUCCESS',
    failed: 'FAILED',
  },
}
