declare module 'express-timeout-handler'
