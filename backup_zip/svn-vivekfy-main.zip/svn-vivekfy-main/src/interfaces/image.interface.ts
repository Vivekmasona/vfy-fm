export type DownloadLink = { quality: string; link: string }[] | boolean
